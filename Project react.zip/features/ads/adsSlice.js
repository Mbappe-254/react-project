import { createSlice } from '@reduxjs/toolkit'
import { ADS } from '../../app/shared/ADS';

const initialState = {
    adsArray: ADS

};

const adsSlice = createSlice({
    name: 'ads',
    initialState

});

export const adsReducer = adsSlice.reducer;

export const selectFeaturedAds = (state) => {
    return state.ads.adsArray.find(
        (ad) => ad.featured);
};